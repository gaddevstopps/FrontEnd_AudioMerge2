import React from 'react';
import './AudioMergeApp.css';

function AudioMergeApp() {
  return (
    <div className="container">
      <h1>Audio Merge System</h1>
      <p>Replace this with the real UI logic.</p>
    </div>
  );
}

export default AudioMergeApp;
